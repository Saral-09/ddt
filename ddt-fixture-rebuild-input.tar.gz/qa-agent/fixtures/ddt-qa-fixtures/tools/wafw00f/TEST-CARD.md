# Wafw00f — QA fixture card

**Category:** WAF fingerprinting

**Fixture mode:** `local_web_only`

## Simple test

Use `http://127.0.0.1:18080/`; expected to report no known WAF on the simple fixture.

## Fixture files

- `common/targets/localhost-url.txt`

## Safety / limitations

Loopback only.

## Instructions for the DDT QA agent

Inspect this tool's actual React component and its user guide before filling fields. Do not assume field names, selectors, CLI arguments, or that this fixture is valid for the tool. Populate the actual UI only with inputs supported by the component. If the component needs a missing service, capture, API key, adapter, or real `.rt` table, mark the test `test_gap` or `dependency_missing`; do not fabricate a valid input.
