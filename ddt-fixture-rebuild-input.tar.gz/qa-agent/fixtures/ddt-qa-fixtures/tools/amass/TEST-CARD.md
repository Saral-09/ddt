# Amass — QA fixture card

**Category:** Domain mapping

**Fixture mode:** `passive_scope_required`

## Simple test

Use `ddt.test` as a placeholder for UI validation; live enumeration requires an explicitly authorised domain and network scope.

## Fixture files

- `common/wordlists/subdomains-test.txt`

## Safety / limitations

Do not run passive internet enumeration as a default fixture.

## Instructions for the DDT QA agent

Inspect this tool's actual React component and its user guide before filling fields. Do not assume field names, selectors, CLI arguments, or that this fixture is valid for the tool. Populate the actual UI only with inputs supported by the component. If the component needs a missing service, capture, API key, adapter, or real `.rt` table, mark the test `test_gap` or `dependency_missing`; do not fabricate a valid input.
